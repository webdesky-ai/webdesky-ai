/*********
* local.js
*********/

let localConfig = {
    hostname: 'localhost',
    port: 7000
}

module.exports = localConfig;