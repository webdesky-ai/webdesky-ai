

module.exports.secretkey = function(req, res){

    var Secret_Key = '@#$SecretKey$%$%$%$%'
}