
const url = 'http://192.168.1.80:7000/';

module.exports = {
    URL : url
}